﻿using UnityEngine;
using System.Collections;
using System.IO;

public class ActorController2 : MonoBehaviour {
	private enum State
	{
		None,
		Ground,
		Fall,
		Jump,
	}

	[SerializeField]
	private float m_moveSpeed;
/*
	[SerializeField]
	private float m_speedUpDelta = 0.1f;

	[SerializeField]
	private float m_stopDelta = 0.33f;

	[SerializeField]
	private float m_turnDelta = 0.05f;
*/
	[SerializeField]
	private LayerMask m_solidMask;

	[SerializeField]
	private int m_allowFallingJumpFrames = 2;

	private OneBody2D m_rigidBody;
	private Animator m_animator;
	private Vector2 m_startingPosition;

	private float m_walkDelta = 0;
	private bool m_isFacingRight = true;
	private bool m_onGround = false;
	private int m_direction = 0;
	private int m_lastOnGroundTime = -1;
	private State m_state = State.None;

	public int direction {
		get {
			return m_direction;
		}
		set {
			m_direction = value;
		}
	}

	public bool onGround {
		get {
			return m_onGround;
		}
		set {
			m_onGround = value;
			m_animator.SetBool ("air", !m_onGround);
		}
	}

	void Start () {
		m_rigidBody = GetComponent<OneBody2D> ();
		m_animator = GetComponent<Animator> ();

		// Try the childen (in the case of the player using a proxy)
		if(m_animator == null)
		{
			Component[] components = transform.GetComponentsInChildren<Animator>();
			if(components.Length > 0) {
				m_animator = components[0] as Animator;
			}
		}

		m_startingPosition = transform.position;
	}

	void Reset() {
		transform.SetParent (null);
		transform.position = m_rigidBody.position;

		m_walkDelta = 0;
		m_direction = 0;

		SetFacingRight(true);
		SetPosition (m_startingPosition);

		m_rigidBody.Reset();
	}

	private void ChangeState(State newState) {
		// End current state
		switch(m_state) {
		case State.Fall:
			break;
		}

		switch (newState) {
		case State.Fall:
			break;
		case State.Ground:
			break;
		}
	}

	private void UpdateState() {
		switch (m_state) {
		case State.Ground:
			m_animator.SetFloat("speed", Mathf.Abs(m_walkDelta));
			break;
		case State.Fall:
			break;
		}
	}

	private void FixedUpdateState() {
	}

	private void HandleGroundStateChange() {
		bool updateLayer = false;

		if (!onGround && m_rigidBody.onGround) {
			// Grounded from falling
			updateLayer = true;
			m_lastOnGroundTime = -1;

			onGround = true;
			ChangeState (State.Ground);
		} else if (onGround && !m_rigidBody.onGround) {
			// Falling from grounded
			updateLayer = true;
			if (m_allowFallingJumpFrames > 0) {
				if (m_lastOnGroundTime == -1) {
					m_lastOnGroundTime = Time.frameCount;
				} else {
					if (Time.frameCount - m_lastOnGroundTime > m_allowFallingJumpFrames) {
						onGround = false;
						ChangeState (State.Fall);
					}
				}
			}
		}

		if (updateLayer) {
			m_animator.SetLayerWeight(1, (onGround && m_lastOnGroundTime == -1 ? 0.0f : 1.0f));
		}
	}

	public void Update() {
		HandleGroundStateChange ();
		UpdateState ();
	}

	void FixedUpdate() {
	}

	private void SetFacingRight(bool isRight) {
		m_isFacingRight = isRight;

		Vector3 localScale = transform.localScale;
		localScale.x = m_isFacingRight ? -1.0f : 1.0f;
		transform.localScale = localScale;
	
		m_animator.SetBool("right", m_isFacingRight);
	}

	private void HorizFlip() {
		SetFacingRight(!m_isFacingRight);
	}

	private void SetPosition(Vector2 newPosition) {
		m_rigidBody.position = m_startingPosition;
		transform.position = m_rigidBody.position;
	}
}
