﻿using UnityEngine;

class ActorState_LedgeGrab : ActorState
{
	public ActorState_LedgeGrab(ActorController parent) : base(parent) {
	}

	public override void Init() {
		rigidBody.gravityScale = 0.0f;
		animator.SetBool ("wall_hang", true);
	}

	public override void FixedUpdate() {
	}

	public override void Jump() {
		parent.SetState(ActorController.State.HangJump);
	}

	public override void Exit() {
		rigidBody.gravityScale = 1.0f;
		animator.SetBool ("wall_hang", false);
	}
};

