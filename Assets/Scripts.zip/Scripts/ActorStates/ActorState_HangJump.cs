﻿using UnityEngine;

class ActorState_HangJump : ActorState
{
	public ActorState_HangJump(ActorController parent, float jumpForce) : base(parent, jumpForce) {
	}

	public override void Init() {
		rigidBody.gravityScale = 0.2f;
		parent.walkDelta = parent.direction;
		rigidBody.velocity = new Vector2(0, jumpForce);
		animator.SetTrigger ("jump");
	}

	public override void FixedUpdate() {
	}

	public override void Jump() {
	}

	public override void Exit() {
	}
};