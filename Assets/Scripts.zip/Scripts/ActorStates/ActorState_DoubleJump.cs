﻿using UnityEngine;

class ActorState_DoubleJump : ActorState
{
	public ActorState_DoubleJump(ActorController parent, float jumpForce) : base(parent, jumpForce) {
	}

	public override void Init() {
		// Double jump
		rigidBody.gravityScale = 1.0f;
		parent.walkDelta = 0;//  (float)m_direction;
		rigidBody.velocity = new Vector2(parent.walkDelta, -jumpForce); // 1?
		animator.SetTrigger ("double_jump");
	}

	public override void FixedUpdate() {
	}

	public override void Jump() {
	}

	public override void Exit() {
	}
};