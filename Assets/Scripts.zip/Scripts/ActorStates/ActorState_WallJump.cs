﻿using UnityEngine;

class ActorState_WallJump : ActorState
{
	public ActorState_WallJump(ActorController parent, float jumpForce) : base(parent, jumpForce) {
	}

	public override void Init() {
		rigidBody.gravityScale = 1.0f;
		parent.walkDelta = Mathf.Sign (rigidBody.wallDirection);
		rigidBody.velocity = new Vector2(0, jumpForce);
		animator.SetTrigger ("jump");
	}

	public override void FixedUpdate() {
	}

	public override void Jump() {
	}

	public override void Exit() {
	}
};