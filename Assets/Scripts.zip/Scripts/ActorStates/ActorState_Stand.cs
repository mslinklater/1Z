﻿using UnityEngine;

class ActorState_Stand : ActorState
{
	public ActorState_Stand(ActorController parent) : base(parent) {
	}

	public override void Init() {
	}

	public override void FixedUpdate() {
	}

	public override void Jump() {
		parent.SetState(ActorController.State.Jump);
	}

	public override void Exit() {
	}
};
