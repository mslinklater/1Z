﻿using UnityEngine;

class ActorState_Fall : ActorState
{
	public ActorState_Fall(ActorController parent) : base(parent) {
	}

	public override void Init() {
		rigidBody.gravityScale = 1.0f;
	}

	public override void FixedUpdate() {
	}

	public override void Jump() {
	}

	public override void Exit() {
	}
};