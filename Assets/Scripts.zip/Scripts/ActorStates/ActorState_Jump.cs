﻿using UnityEngine;

class ActorState_Jump : ActorState
{
	public ActorState_Jump(ActorController parent, float jumpForce) : base(parent, jumpForce) {
	}

	public override void Init() {
		rigidBody.velocity = new Vector2(0,jumpForce);
		rigidBody.gravityScale = 0.2f;
		parent.transform.SetParent (null);
		animator.SetTrigger("jump");
	}

	public override void FixedUpdate() {
	}

	public override void Jump() {
		parent.SetState(ActorController.State.DoubleJump);
	}

	public override void Exit() {
	}
};